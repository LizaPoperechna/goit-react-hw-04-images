import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from 'components/App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App style={{
                display: 'grid',
                gridTemplateColumns: '1fr',
                gridGap: 16,
                paddingBottom: 24,}}/>
  </React.StrictMode>
);
